export class Usermodel {
    userID: string='';
    firstName: string='';
    lastName:string='';
    dob: string='';
    address: string='';
}
