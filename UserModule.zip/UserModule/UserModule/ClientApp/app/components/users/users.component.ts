﻿//import { Component } from '@angular/core';
import { Component, Inject, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { Http, RequestOptions, RequestMethod, Headers } from '@angular/http';
import { Usermodel } from '../users/usermodel';
import { Observable } from "rxjs/Observable";
import { URLSearchParams } from '@angular/http';
import { FormsModule, NgForm } from '@angular/forms';



@Component({
    selector: 'users',
    templateUrl: './users.component.html',
    styleUrls: ['./users.component.css']
})


export class UsersComponent {
    constructor(private http: Http) { }
    public users: Usermodel[];
    display = 'none';
    modaldisplay = 'none';


    user: Usermodel;
    deleteUser: Usermodel;

    ngOnInit() {
        this.getUsers();
        this.resetAllInputs();
    }

    resetAllInputs()
    {
        this.user = {
            userID: '',
            firstName: '',
            lastName: '',
            dob: '',
            address: '',
        }
    }
    getUsers() {
        this.http.get('/api/User/GetUsers').subscribe(data => { this.users = data.json() as Usermodel[] });
    }

    AddUser(usr: NgForm) {
        var body = JSON.stringify(usr.value);
        var headerOptions = new Headers({ 'Content-Type': 'application/json' });
        //headerOptions.append('Accept', 'application/json');
        //headerOptions.append('Access-Control-Allow-Methods', 'POST, GET, OPTIONS, DELETE, PUT');
        //headerOptions.append('Access-Control-Allow-Origin', '*');
        //headerOptions.append('Access-Control-Allow-Headers', "X-Requested-With, Content-Type, Origin, Authorization, Accept, Client-Security-Token, Accept-Encoding");
        var requestOptions = new RequestOptions({ method: RequestMethod.Post, headers: headerOptions });
        var result = this.http.post('/api/User/AddUser/', body, requestOptions).subscribe(res =>
        {
            console.log('Done');
            this.ResetData(usr);
            this.getUsers();
        });       
        return result;
    }

    EditUser(usr: NgForm) {
        var body = JSON.stringify(usr.value);
        var headerOptions = new Headers({ 'Content-Type': 'application/json' });
        var requestOptions = new RequestOptions({ method: RequestMethod.Put, headers: headerOptions });
        var result = this.http.post('/api/User/EditUser/', body, requestOptions).subscribe(res =>
        {
            console.log('Done');
            this.ResetData(usr);
            this.getUsers();
        });
        return result;
    }

    DeleteUser(deleteUser: Usermodel) {
        var body = JSON.stringify(deleteUser);
        var headerOptions = new Headers({ 'Content-Type': 'application/json' });
        var requestOptions = new RequestOptions({ method: RequestMethod.Delete, headers: headerOptions });
        var result = this.http.post('/api/User/DeleteUser/', body, requestOptions).subscribe(res => {
            console.log('Done');
            this.getUsers();
        });
        return result;
    }
    
    OnSubmit(usr: NgForm) {
        if (usr.value.userID == '') {
            this.AddUser(usr);
        }
        else {
            this.EditUser(usr);
        }
        this.onCloseUserModal();
        
    }

    ResetData(usr: NgForm)
    {
        if (usr != null)
        {
            usr.reset();
        }

        this.resetAllInputs();
    }

    onDelete(user: Usermodel, usr: Usermodel) {
        this.modaldisplay = 'block';
        this.deleteUser = {
            userID: user.userID,
            firstName: user.firstName,
            lastName: user.lastName,
            dob: user.dob,
            address: user.address,
        }
    }

    onCloseModal() {
        this.modaldisplay = 'none';
    }

    onDeleteUser(deleteUser: Usermodel)
    {
        this.DeleteUser(deleteUser);
        this.onCloseModal();
    }

    onCheck(user: Usermodel, usr: Usermodel) {
        this.user = {
            userID: user.userID,
            firstName: user.firstName,
            lastName: user.lastName,
            dob: user.dob,
            address: user.address,
        }
        this.display = 'block';
    }


    openModal() {
        this.display = 'block';
        this.resetAllInputs();
    }
    onCloseUserModal() {
        this.display = 'none';
    }


}



