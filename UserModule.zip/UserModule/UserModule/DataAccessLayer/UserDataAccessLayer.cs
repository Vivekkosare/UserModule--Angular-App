﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Threading.Tasks;
using UserModule.Models;

namespace UserModule.DataAccessLayer
{
    public class UserDataAccessLayer
    {
        public static IConfiguration Configuration { get; set; }
        public static string UserFile { get; set; }

        public UserDataAccessLayer()
        {
            UserFile = GetUserDataFile();
        }

        private string GetUserDataFile()
        {
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");

            Configuration = builder.Build();

            return Directory.GetCurrentDirectory() + Configuration.GetSection("UserData").Value;
        }
        public async Task<IEnumerable<Usermodel>> GetUsers()
        {
            string UserData = File.ReadAllText(UserFile);
            return JsonConvert.DeserializeObject<List<Usermodel>>(UserData);
        }

        public async Task<Tuple<IEnumerable<Usermodel>, bool>> DeleteUser(Usermodel User)
        {
            bool IsUserDeleted = false;
            var ExistingUsers = await GetUsers();

            var DeletedUserData = new Tuple<IEnumerable<Usermodel>, bool>(ExistingUsers, IsUserDeleted);

            var UserDataChange = ExistingUsers.Where(x => x.userID == User.userID).Select(x => x);
            if (UserDataChange != null && UserDataChange.Count() > 0)
            {
                var DeleteData = UserDataChange.ToList()[0];
                if (DeleteData.userID != User.userID)
                {
                    IsUserDeleted = false;
                }
                else
                {
                    var UpdatedUsers = ExistingUsers.Where(x => x.userID != User.userID);
                    var UpdatedUsersJSON = JsonConvert.SerializeObject(UpdatedUsers);

                    File.WriteAllText(UserFile, "");
                    File.AppendAllText(UserFile, UpdatedUsersJSON);

                    IsUserDeleted = true;
                    DeletedUserData = new Tuple<IEnumerable<Usermodel>, bool>(UpdatedUsers, IsUserDeleted);
                }
            }
            else
            {
                IsUserDeleted = false;
                DeletedUserData = new Tuple<IEnumerable<Usermodel>, bool>(ExistingUsers, IsUserDeleted);
            }
            return DeletedUserData;
        }
        
        public async Task<Tuple<IEnumerable<Usermodel>, bool>> EditUser(Usermodel User)
        {
            bool IsUserEdited = false;
            var ExistingUsers = await GetUsers();

            var EditedUserData = new Tuple<IEnumerable<Usermodel>, bool>(ExistingUsers, IsUserEdited);


            var UserDataChange = ExistingUsers.Where(x => x.userID == User.userID).Select(x => x);
            var EditData = UserDataChange.ToList()[0];
            if (EditData.firstName== User.firstName && EditData.lastName== User.lastName && EditData.dob== User.dob && EditData.address== User.address)
            {
                IsUserEdited = false;
            }
            else
            {
                ExistingUsers.Where(x => x.userID == User.userID).Select(usr => { usr.firstName = User.firstName; usr.lastName = User.lastName; ; usr.dob = User.dob; usr.address = User.address; return usr; }).ToList();
                var ExistingUsersJSON = JsonConvert.SerializeObject(ExistingUsers);

                File.WriteAllText(UserFile, "");
                File.AppendAllText(UserFile, ExistingUsersJSON);

                IsUserEdited = true;
            }

            EditedUserData = new Tuple<IEnumerable<Usermodel>, bool>(ExistingUsers, IsUserEdited);


            return EditedUserData;
        }
        

        public async Task<Tuple<IEnumerable<Usermodel>, bool>> AddUser(Usermodel User)
        {
            bool UserAdded = false;
            var ExistingUsers = await GetUsers();

            var AddedUserData = new Tuple<IEnumerable<Usermodel>, bool>(ExistingUsers, UserAdded);

            if (ExistingUsers == null)
            {
                File.AppendAllText(UserFile, "[");
                User.userID = 1;
                UserAdded = true;
                var NewUserData = JsonConvert.SerializeObject(User);
                File.AppendAllText(UserFile, NewUserData);
                File.AppendAllText(UserFile, "]");

                AddedUserData = new Tuple<IEnumerable<Usermodel>, bool>(await GetUsers(), UserAdded);
            }
            else
            {
                var UserExists = ExistingUsers.Where(x => x.firstName == User.firstName && x.lastName == User.lastName);
                if (UserExists.Count() == 0)
                {
                    var ExistingUsersData = JsonConvert.SerializeObject(ExistingUsers);
                    ExistingUsersData = ExistingUsersData.Remove(ExistingUsersData.Length - 1);
                    File.WriteAllText(UserFile, ExistingUsersData);
                    File.AppendAllText(UserFile, ",");

                    var MaxuserID = ExistingUsers.Max(x => x.userID);

                    User.userID = MaxuserID + 1;
                    UserAdded = true;

                    var NewUserData = JsonConvert.SerializeObject(User);
                    File.AppendAllText(UserFile, NewUserData);
                    File.AppendAllText(UserFile, "]");

                    AddedUserData = new Tuple<IEnumerable<Usermodel>, bool>(await GetUsers(), UserAdded);
                }
                else
                {
                    UserAdded = false;
                    AddedUserData = new Tuple<IEnumerable<Usermodel>, bool>(await GetUsers(), UserAdded);
                }
            }
            return AddedUserData;
        }
    }
}
