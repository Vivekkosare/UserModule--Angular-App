﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using UserModule.Models;
using UserModule.DataAccessLayer;
using System.Net.Http;
//using System.Net.Http.Formatting;
using System.Net;
using Newtonsoft.Json;
//using System.Web.Http;
using Microsoft.AspNetCore.Cors;
using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;

namespace UserModule.Controllers
{
    //[Produces("application/json")]
    [EnableCors("UserAPICors")]
    public class UserController : Controller
    {

        [HttpGet]
        [Route("api/User/GetUsers")]
        public async Task<IActionResult> GetUsers()
        {
            var Users = await new UserDataAccessLayer().GetUsers();
            if (Users == null || Users.Count() == 0)
            {
                return NotFound("No data found");
            }
            else
            {
                return Ok(Users);
            }

        }


        [HttpPost]
        [Route("api/User/AddUser")]
        public async Task<IActionResult> AddUser([FromBody] JObject json)
        // public async Task<IActionResult> AddUser(Usermodel usr)
        {
            string UserJSON = json.ToString(Newtonsoft.Json.Formatting.Indented);
            Usermodel usr = JsonConvert.DeserializeObject<Usermodel>(UserJSON);
            var AddedUser = await new UserDataAccessLayer().AddUser(usr);
            if (AddedUser.Item2.Equals(false))
            {
                return NotFound("User already exists");
            }
            else
            {
                return Ok(AddedUser.Item1);
            }
        }

        [HttpPut]
        [Route("api/User/EditUser")]
        public async Task<IActionResult> EditUser([FromBody] JObject json)
        {
            string UserJSON = json.ToString(Newtonsoft.Json.Formatting.Indented);
            Usermodel User = JsonConvert.DeserializeObject<Usermodel>(UserJSON);
            var EditedUser = await new UserDataAccessLayer().EditUser(User);
            if (EditedUser.Item2.Equals(false))
            {
                return NotFound("There is no change in the data");
            }
            else
            {
                return Ok(EditedUser.Item1);
            }
        }

        [HttpDelete]
        [Route("api/User/DeleteUser")]
        public async Task<IActionResult> DeleteUser([FromBody] JObject json)
        {
            string UserJSON = json.ToString(Newtonsoft.Json.Formatting.Indented);
            Usermodel User = JsonConvert.DeserializeObject<Usermodel>(UserJSON);

            var DeletedUser = await new UserDataAccessLayer().DeleteUser(User);
            if (DeletedUser.Item2.Equals(false))
            {
                return NotFound("This data is not available to be deleted");
            }
            else
            {
                return Ok(DeletedUser.Item1);
            }
        }



    }
}